      	<hr>

      	<footer class="page-footer font-small special-color-dark pt-4"


        <div class="col-md-6 mt-md-0 mt-3">
<center>
          <!-- Content -->
          <h5 class="text-uppercase font-weight-bold">Quotes of the Day</h5>
          <p>"People often say that motivation doesn't last. Well, neither does bathing -- that's why we recommend it daily." -Zig Ziglar</p>
</center>
        </div>
        

    </div>

        	<div class="footer-copyright text-center py-3">@2019 Copyright:
          <a href="index.php"> www.ebookstore.com</a>
    </div>
        	
      	</footer>
    </div> <!-- /container -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="./bootstrap/js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>